# Richfield Connect

## Run the website

1. Install Node.js 18 or newer.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm run dev` and open the local address shown in the terminal.

To verify a production build, run `npm run build`. To serve that build locally,
run `npm run preview`.
