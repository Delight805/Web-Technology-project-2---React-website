import React, {
  createContext,
  useContext,
  useEffect,
  useReducer
} from "react";

const AppContext = createContext();

const initialState = {
  user: null,
  posts: [],
  hydrated: false
};

function appReducer(state, action) {
  switch (action.type) {

    case "HYDRATE":
      return {
        ...state,
        user: action.payload.user,
        posts: action.payload.posts,
        hydrated: true
      };

    case "REGISTER_USER":
      return {
        ...state,
        user: action.payload
      };

    case "ADD_POST":
      return {
        ...state,
        posts: [action.payload, ...state.posts]
      };

    case "TOGGLE_LIKE":
      return {
        ...state,
        posts: state.posts.map((post) =>
          post.id === action.payload
            ? {
                ...post,
                liked: !post.liked,
                likes: post.liked
                  ? post.likes - 1
                  : post.likes + 1
              }
            : post
        )
      };

    case "DELETE_POST":
      return {
        ...state,
        posts: state.posts.filter(
          (post) => post.id !== action.payload
        )
      };

    default:
      return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(
    appReducer,
    initialState
  );

  useEffect(() => {
    const savedUser = localStorage.getItem("richfieldUser");
    const savedPosts = localStorage.getItem("richfieldPosts");

    dispatch({
      type: "HYDRATE",
      payload: {
        user: savedUser ? JSON.parse(savedUser) : null,
        posts: savedPosts ? JSON.parse(savedPosts) : []
      }
    });
  }, []);

  useEffect(() => {
    if (!state.hydrated) return;

    if (state.user) {
      localStorage.setItem(
        "richfieldUser",
        JSON.stringify(state.user)
      );
    } else {
      localStorage.removeItem("richfieldUser");
    }
  }, [state.user, state.hydrated]);

  useEffect(() => {
    if (!state.hydrated) return;

    localStorage.setItem(
      "richfieldPosts",
      JSON.stringify(state.posts)
    );
  }, [state.posts, state.hydrated]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  return useContext(AppContext);
}
