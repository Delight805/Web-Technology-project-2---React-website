import { Link } from "react-router-dom";
import { useAppContext } from "../context/AppContext";
import CreatePost from "../components/CreatePost";
import Post from "../components/Post";

function Feed() {
  const { state, dispatch } = useAppContext();

  const user = state.user;
  const posts = state.posts;

  function handleCreatePost(content) {
    const newPost = {
      id: Date.now().toString(),
      author: user.fullName,
      content: content,
      createdAt: new Date().toISOString(),
      likes: 0,
      liked: false
    };

    dispatch({
      type: "ADD_POST",
      payload: newPost
    });
  }

  function handleLike(postId) {
    dispatch({
      type: "TOGGLE_LIKE",
      payload: postId
    });
  }

  function handleDelete(postId) {
    dispatch({
      type: "DELETE_POST",
      payload: postId
    });
  }

  if (!state.hydrated) {
    return <p>Loading student feed...</p>;
  }

  if (!user) {
    return (
      <main className="page-container">
        <h1>Student Feed</h1>

        <p>Please register before accessing the student feed.</p>

        <Link to="/signup" className="btn btn-primary">
          Register Now
        </Link>
      </main>
    );
  }

  return (
    <main className="page-container feed-page">
      <section className="feed-heading">
        <h1>Student Feed</h1>

        <p>
          Connect with other students and share your academic experiences.
        </p>
      </section>

      <CreatePost onCreatePost={handleCreatePost} />

      <section className="posts-section">
        <h2>Recent Posts</h2>

        {posts.length === 0 ? (
          <p className="empty-feed">
            No posts yet. Be the first student to share something!
          </p>
        ) : (
          posts.map((post) => (
            <Post
              key={post.id}
              post={post}
              onLike={handleLike}
              onDelete={handleDelete}
              canDelete={post.author === user.fullName}
            />
          ))
        )}
      </section>
    </main>
  );
}

export default Feed;
