import React from "react";
import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="home-page">

        <section className="hero">
        <div className="hero-content">
          <p className="hero-label">WELCOME TO YOUR ACADEMIC COMMUNITY</p>

          <h1>Richfield Connect</h1>

          <h2>
            Connect. Collaborate. Grow.
          </h2>

          <p>
            A dedicated academic platform where Richfield
            students can connect with peers, share ideas
            and build meaningful academic relationships.
          </p>

          <Link to="/signup" className="primary-button">
            Register Now
          </Link>
        </div>

        <div className="hero-logo">
          <span>RC</span>
          <p>Richfield Connect</p>
        </div>
      </section>

      <section className="features-section">
        <div className="section-heading">
          <p className="hero-label">WHAT YOU CAN DO</p>
          <h2>Discover Your Academic Community</h2>
          <p>
            Everything you need to connect and collaborate
            with fellow students.
          </p>
        </div>

        <div className="features-grid">

          <div className="feature-card">
            <div className="feature-icon">01</div>
            <h3>Connect with Peers</h3>
            <p>
              Build academic relationships and connect
              with other students who share your interests.
            </p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">02</div>
            <h3>Share Academic Ideas</h3>
            <p>
              Share thoughts, discuss topics and exchange
              knowledge with the student community.
            </p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">03</div>
            <h3>Build Your Profile</h3>
            <p>
              Create a personal academic profile that
              highlights your interests and skills.
            </p>
          </div>

        </div>
      </section>

      <section className="home-cta">
        <h2>Become Part of the Community</h2>
        <p>
          Start connecting with fellow students today.
        </p>
        <Link to="/signup" className="primary-button">
          Get Started
        </Link>
      </section>

    </div>
  );
}

export default Home;
