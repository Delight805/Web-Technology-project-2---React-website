import React from "react";
import { Link } from "react-router-dom";
import { useAppContext } from "../context/Appcontext.jsx";

function Profile() {
  const { state } = useAppContext();

  const user = state.user;

  if (!user) {
    return (
      <main className="page-container">
        <h1>No profile found</h1>

        <p>
          You need to register before you can view your profile.
        </p>

        <Link to="/signup" className="btn btn-primary">
          Register Now
        </Link>
      </main>
    );
  }

  return (
    <main className="page-container">
      <section className="profile-card">
        <div className="profile-avatar">
          {user.fullName.charAt(0).toUpperCase()}
        </div>

        <h1>{user.fullName}</h1>

        <p className="profile-campus">
          {user.campus}
        </p>

        <div className="profile-details">
          <div>
            <strong>Student Number:</strong>
            <p>{user.studentNumber}</p>
          </div>

          <div>
            <strong>Email Address:</strong>
            <p>{user.email}</p>
          </div>

          <div>
            <strong>About Me:</strong>
            <p>{user.bio || "No biography provided."}</p>
          </div>

          <div>
            <strong>My Interests:</strong>

            <div className="interest-tags">
              {user.interests?.length > 0 ? (
                user.interests.map((interest, index) => (
                  <span className="interest-tag" key={index}>
                    {interest}
                  </span>
                ))
              ) : (
                <p>No interests added.</p>
              )}
            </div>
          </div>
        </div>

        <Link to="/feed" className="btn btn-primary">
          Visit Student Feed
        </Link>
      </section>
    </main>
  );
}

export default Profile;

