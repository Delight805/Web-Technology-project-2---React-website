import React from "react";

function About() {

	const guidelines = [
		"Treat all students with respect and professionalism.",
		"Respect other students' opinions and perspectives.",
		"Do not share private or confidential information.",
		"Avoid offensive, discriminatory or inappropriate content."

	];
	
	return (
	<div className = "about-page">
	
	<section className = "about-hero">
	<p className = "hero-label"> About Our Platform</p>
	
	<h1> Connecting Students Through Learning</h1>
	
	<p>
	Richfield Connecting
	</p>
	</section>
	
	<section className = "about-content">
	
	<div className = "about-section">
	<h2> Our Purpose </h2>
	
	<p> The Purpose of this platform is to connect students from different campuses and provide a space for them to share their knowledge, experiences, and interests. It aims to foster a sense of community among students and encourage collaboration and learning.
	</p>
	
	<p> The plateform ensources that students can connect with each other, share their ideas, and learn from one another. It provides a space for students to ask questions, seek advice, and share their experiences. The platform also allows students to showcase their work, projects, and achievements, which can help them build their portfolios and gain recognition for their efforts.
	</p>
	
	</div>
	
	<div className = "about-section">
	<h2> Community Guidelines</h2>
	
	<p>
	Ensure that you:
	</p>
	
	<ul className = "guidelines-list">
		{guidelines.map((guideline, index) => (
			<li key = {index} > {guideline} </li>
		))}
		</ul>
		</div>
		
		<div className = "contact-section">
		<h2>Contact Information</h2>
		
		<p>
		For assitance use the information below to contact us. We are here to help you with any questions or concerns you may have.
		</p>
		
		<p>
			<strong> Email: </strong> {" "}
			Richfield@my.richfield.ac.za
		</p>
		
		<p>
			<strong>Campus: </strong> {" "}
			Any Campus registered with Richfield
		</p>

		<p>
			<strong>Contact: </strong> {" "}
			+27 87 804 3797
		</p>
		</div>
		
	</section>
	</div>
	);
}
export default About;