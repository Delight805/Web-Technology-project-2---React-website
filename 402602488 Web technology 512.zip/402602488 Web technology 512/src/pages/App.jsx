import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import NavigationBar from "../components/NavigationBar.jsx";
import Footer from "../components/Footer.jsx";
import Home from "./Home.jsx";
import About from "./About.jsx";
import SignUpForm from "./SignUpForm.jsx";
import Profile from "./Profile.jsx";
import Feed from "./Feed.jsx";

function App() {
  return (
    <BrowserRouter>
      <NavigationBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/signup" element={<SignUpForm />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/feed" element={<Feed />} />
        <Route path="*" element={<Home />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}

export default App;
