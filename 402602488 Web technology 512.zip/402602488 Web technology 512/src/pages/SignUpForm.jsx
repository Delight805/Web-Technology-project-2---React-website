import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import ProfilePreview from "../components/ProfilePreview";
import { useAppContext } from "../context/Appcontext.jsx";

const campusOptions = [
  "Johannesburg",
  "Durban",
  "Pretoria",
  "Centurion",
  "Polokwane",
  "Bryanston",
  "Cape Town"
];

const interestOptions = [
  "Programming",
  "Business Analytics",
  "Networking"
];

function SignUpForm() {
  const navigate = useNavigate();
  const { dispatch } = useAppContext();

  const [formData, setFormData] = useState({
    fullName: "",
    studentNumber: "",
    campus: "",
    email: "",
    password: "",
    confirmPassword: "",
    interests: [],
    bio: "",
    terms: false
  });

  const [errors, setErrors] = useState({});

  function validateField(name, value, currentData = formData) {

    switch (name) {

      case "fullName":
        if (!value.trim()) {
          return "Full name is required.";
        }
        break;

      case "studentNumber":
        if (!/^\d+$/.test(value)) {
          return "Student number must contain numbers only.";
        }
        if (value.length < 6) {
          return "Student number must contain at least 6 digits.";
        }
        break;

      case "campus":
        if (!value) {
          return "Please select your campus.";
        }
        break;

      case "email":
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          return "Please enter a valid email address.";
        }
        break;

      case "password":
        if (value.length < 8) {
          return "Password must contain at least 8 characters.";
        }
        break;

      case "confirmPassword":
        if (!value || value !== currentData.password) {
          return "Passwords must match.";
        }
        break;

      case "interests":
        if (value.length === 0) {
          return "Please select at least one interest.";
        }
        break;

      case "bio":
        if (!value.trim()) {
          return "A short bio is required.";
        }
        if (value.trim().length < 20) {
          return "Your bio must contain at least 20 characters.";
        }
        break;

      case "terms":
        if (!value) {
          return "You must accept the terms and conditions.";
        }
        break;

      default:
        break;
    }

    return "";
  }

  function handleChange(event) {
    const { name, value, checked, type } = event.target;

    const updatedValue = type === "checkbox" &&
      name !== "interests"
        ? checked
        : value;

    const updatedData = {
      ...formData,
      [name]: updatedValue
    };

    setFormData(updatedData);

    if (errors[name]) {
      setErrors((previousErrors) => ({
        ...previousErrors,
        [name]: validateField(
          name,
          updatedValue,
          updatedData
        )
      }));
    }

    if (name === "password" && errors.confirmPassword) {
      setErrors((previousErrors) => ({
        ...previousErrors,
        confirmPassword: validateField(
          "confirmPassword",
          updatedData.confirmPassword,
          updatedData
        )
      }));
    }
  }

  function handleInterestChange(event) {
    const { value, checked } = event.target;

    const updatedInterests = checked
      ? [...formData.interests, value]
      : formData.interests.filter(
          (interest) => interest !== value
        );

    const updatedData = {
      ...formData,
      interests: updatedInterests
    };

    setFormData(updatedData);

    if (errors.interests) {
      setErrors((previousErrors) => ({
        ...previousErrors,
        interests: validateField(
          "interests",
          updatedInterests,
          updatedData
        )
      }));
    }
  }

  function handleBlur(event) {
    const { name, value, checked, type } = event.target;

    const fieldValue = type === "checkbox"
      ? checked
      : value;

    const error = validateField(name, fieldValue);

    setErrors((previousErrors) => ({
      ...previousErrors,
      [name]: error
    }));
  }

  function handleSubmit(event) {
    event.preventDefault();

    const validationErrors = {};

    Object.keys(formData).forEach((field) => {
      const error = validateField(
        field,
        formData[field],
        formData
      );

      if (error) {
        validationErrors[field] = error;
      }
    });

    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      return;
    }

    const userProfile = {
      fullName: formData.fullName.trim(),
      studentNumber: formData.studentNumber,
      campus: formData.campus,
      email: formData.email.trim(),
      interests: formData.interests,
      bio: formData.bio.trim()
    };

    dispatch({
      type: "REGISTER_USER",
      payload: userProfile
    });

    navigate("/profile");
  }

  return (
    <div className="signup-page">

      <section className="signup-heading">
        <p className="hero-label">JOIN THE COMMUNITY</p>
        <h1>Create Your Student Profile</h1>
        <p>
          Register with Richfield Connect and start
          connecting with fellow students.
        </p>
      </section>

      <div className="signup-layout">

        <form className="signup-form" onSubmit={handleSubmit}>

          <h2>Registration Details</h2>

          <div className="form-group">
            <label htmlFor="fullName">Full Name</label>

            <input
              id="fullName"
              type="text"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="Enter your full name"
            />

            {errors.fullName && (
              <p className="error-message">{errors.fullName}</p>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="studentNumber">Student Number</label>

            <input
              id="studentNumber"
              type="text"
              name="studentNumber"
              value={formData.studentNumber}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="Enter your student number"
            />

            {errors.studentNumber && (
              <p className="error-message">{errors.studentNumber}</p>
            )}
          </div>

          {/* Campus */}
          <div className="form-group">
            <label htmlFor="campus">Campus</label>

            <select
              id="campus"
              name="campus"
              value={formData.campus}
              onChange={handleChange}
              onBlur={handleBlur}
            >
              <option value="">Select your campus</option>

              {campusOptions.map((campus) => (
                <option key={campus} value={campus}>
                  {campus}
                </option>
              ))}
            </select>

            {errors.campus && (
              <p className="error-message">{errors.campus}</p>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="email">Email Address</label>

            <input
              id="email"
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="Enter your email address"
            />

            {errors.email && (
              <p className="error-message">{errors.email}</p>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>

            <input
              id="password"
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="Minimum 8 characters"
            />

            {errors.password && (
              <p className="error-message">{errors.password}</p>
            )}
          </div>

          {/* Confirm Password */}
          <div className="form-group">
            <label htmlFor="confirmPassword">
              Confirm Password
            </label>

            <input
              id="confirmPassword"
              type="password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="Confirm your password"
            />

            {errors.confirmPassword && (
              <p className="error-message">
                {errors.confirmPassword}
              </p>
            )}
          </div>

          {/* Interests */}
          <fieldset className="form-group">
            <legend>Choose Your Interests</legend>

            <div className="checkbox-grid">
              {interestOptions.map((interest) => (
                <label key={interest} className="checkbox-label">
                  <input
                    type="checkbox"
                    name="interests"
                    value={interest}
                    checked={formData.interests.includes(interest)}
                    onChange={handleInterestChange}
                  />
                  {interest}
                </label>
              ))}
            </div>

            {errors.interests && (
              <p className="error-message">{errors.interests}</p>
            )}
          </fieldset>

          {/* Bio */}
          <div className="form-group">
            <label htmlFor="bio">Short Bio</label>

            <textarea
              id="bio"
              name="bio"
              value={formData.bio}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="Tell us a little about yourself..."
              rows="5"
            />

            {errors.bio && (
              <p className="error-message">{errors.bio}</p>
            )}
          </div>

          <div className="form-group terms-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="terms"
                checked={formData.terms}
                onChange={handleChange}
                onBlur={handleBlur}
              />
              I accept the Terms and Conditions.
            </label>

            {errors.terms && (
              <p className="error-message">{errors.terms}</p>
            )}
          </div>

          <button type="submit" className="primary-button">
            Register
          </button>

        </form>

        <ProfilePreview formData={formData} />

      </div>
    </div>
  );
}

export default SignUpForm;
