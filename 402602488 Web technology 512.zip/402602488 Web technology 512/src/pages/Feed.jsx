import React from "react";
import { Link } from "react-router-dom";
import CreatePost from "../components/Createpost.jsx";
import Post from "../components/Post.jsx";
import { useAppContext } from "../context/Appcontext.jsx";

export default function Feed() {
  const { state, dispatch } = useAppContext();
  const user = state.user;
  const posts = Array.isArray(state.posts) ? state.posts : [];

  function handleCreatePost(content) {
    dispatch({
      type: "ADD_POST",
      payload: {
        id: Date.now().toString(),
        author: user.fullName,
        content,
        createdAt: new Date().toISOString(),
        likes: 0,
        liked: false
      }
    });
  }

  function handleLike(postId) {
    dispatch({ type: "TOGGLE_LIKE", payload: postId });
  }

  function handleDelete(postId) {
    dispatch({ type: "DELETE_POST", payload: postId });
  }

  return (
    <div className="page feed-page">
      <section className="page-heading feed-heading">
        <span className="eyebrow">Student community</span>
        <h1>Ideas grow when we share.</h1>
        <p>Join the academic conversation. Share what you're learning, ask thoughtful questions, and support your peers.</p>
      </section>
      {!user && (
        <div className="notice-banner">
          <span>ℹ</span><p>You can read the feed, but you need a registered profile to publish a post.</p>
          <Link to="/signup">Register</Link>
        </div>
      )}
      <div className="feed-layout">
        <div className="feed-main">
          {user && <CreatePost onCreatePost={handleCreatePost} />}
          <div className="feed-list-heading"><h2>Latest posts</h2><span>{posts.length} {posts.length === 1 ? "post" : "posts"}</span></div>
          {posts.length ? (
            <div className="post-list">{posts.map((post) => <Post post={post} key={post.id} onLike={handleLike} onDelete={handleDelete} canDelete={post.author === user?.fullName} />)}</div>
          ) : (
            <div className="empty-feed card">
              <div className="empty-icon">✦</div><h3>Start the conversation</h3>
              <p>No posts have been shared yet. Once registered, you can create the first post for the community.</p>
            </div>
          )}
        </div>
        <aside className="feed-sidebar">
          <div className="sidebar-card">
            <span className="sidebar-icon">✦</span><h3>Community first</h3>
            <p>Keep conversations respectful, helpful, and focused on learning.</p>
          </div>
          <div className="sidebar-card">
            <span className="sidebar-icon">↗</span><h3>Make it useful</h3>
            <p>Share study tips, ask questions, and acknowledge other people's ideas.</p>
          </div>
        </aside>
      </div>
    </div>
  );
}
