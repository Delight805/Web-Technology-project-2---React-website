import React from "react";
import { Link } from "react-router-dom";

function Footer() {
	return (
	<footer className = "footer">
	<div>
	<h3>Richfield Connect</h3>
	
	<p> Connecting Students
	</p>
	</div>
	
	<div className = "footer-links">
		<Link to = "/"> Home </Link>
		<Link to = "/about"> About </Link>
		<Link to = "/signup"> Register </Link>
		<Link to = "/feed"> Student Feed </Link>
	</div>
	
	<p className = "copyright">
	{new Date().getFullYear()} Richfield Connect.
	All rights resserved.
	</p>
	</footer>
	);
}
export default Footer;
		
		
	