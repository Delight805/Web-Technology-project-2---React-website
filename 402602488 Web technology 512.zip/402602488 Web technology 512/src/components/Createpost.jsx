import React, { useState } from "react";

function CreatePost({ onCreatePost }) {
  const [content, setContent] = useState("");

  function handleSubmit(event) {
    event.preventDefault();

    if (content.trim() === "") {
      return;
    }

    onCreatePost(content.trim());

    setContent("");
  }

  return (
    <form className="create-post-card" onSubmit={handleSubmit}>
      <h2>Create a Post</h2>

      <textarea
        value={content}
        onChange={(event) => setContent(event.target.value)}
        placeholder="Share something with your fellow students..."
        rows="4"
        maxLength="500"
      />

      <div className="create-post-footer">
        <small>{content.length}/500 characters</small>

        <button type="submit" className="btn btn-primary">
          Publish Post
        </button>
      </div>
    </form>
  );
}

export default CreatePost;
