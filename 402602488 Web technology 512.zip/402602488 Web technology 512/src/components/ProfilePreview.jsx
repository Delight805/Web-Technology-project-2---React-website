import React from "react";

function ProfilePreview({ formData }) {

  return (
    <div className="preview-card">

      <div className="preview-heading">
        <p className="hero-label">LIVE PREVIEW</p>
        <h2>Your Academic Profile</h2>
        <p>
          This is how your profile information will appear.
        </p>
      </div>

      <div className="preview-avatar">
        {formData.fullName
          ? formData.fullName.charAt(0).toUpperCase()
          : "?"}
      </div>

      <h3>
        {formData.fullName || "Your Name"}
      </h3>

      <p className="preview-campus">
        {formData.campus || "Your Campus"}
      </p>

      <div className="preview-bio">
        <h4>About Me</h4>
        <p>
          {formData.bio || "Your short bio will appear here."}
        </p>
      </div>

      <div className="preview-interests">
        <h4>My Interests</h4>

        <div className="interest-tags">
          {formData.interests.length > 0 ? (
            formData.interests.map((interest) => (
              <span className="interest-tag" key={interest}>
                {interest}
              </span>
            ))
          ) : (
            <p>Select your interests to see them here.</p>
          )}
        </div>
      </div>

    </div>
  );
}

export default ProfilePreview;
