import React from "react";
function Post({ post, onLike, onDelete, canDelete }) {
  const postDate = new Date(post.createdAt).toLocaleString();

  return (
    <article className="post-card">
      <div className="post-header">
        <div className="post-avatar">
          {post.author.charAt(0).toUpperCase()}
        </div>

        <div>
          <h3>{post.author}</h3>
          <small>{postDate}</small>
        </div>
      </div>

      <p className="post-content">{post.content}</p>

      <div className="post-actions">
        <button
          type="button"
          className="post-action-button"
          onClick={() => onLike(post.id)}
        >
          {post.liked ? "Unlike" : "Like"} ({post.likes})
        </button>

        {canDelete && (
          <button
            type="button"
            className="post-action-button delete-button"
            onClick={() => onDelete(post.id)}
          >
            Delete
          </button>
        )}
      </div>
    </article>
  );
}

export default Post;


