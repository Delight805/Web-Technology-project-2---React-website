import React from "react";
import { Link } from "react-router-dom";

function NavigationBar() {
	return (
	<nav className="NavigationBar">
	<Link to = "/" className = "logo">
		Richfield Connect
	</Link>
	
	<div className = "nav-links">
	
		<Link to = "/"> Home </Link>
		<Link to = "/about"> About </Link>
		<Link to = "/signup"> Sign Up</Link>
		<Link to = "/profile"> Profile </Link>
		<Link to = "/feed"> Feed </Link>
	</div>
	</nav>
	);
	}
	
	export default NavigationBar;
		