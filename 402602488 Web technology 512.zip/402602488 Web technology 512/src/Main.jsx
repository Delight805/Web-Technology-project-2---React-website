import React from "react";
import ReactDOM from "react-dom/client";
import App from "./pages/App.jsx";
import { AppProvider } from "./context/Appcontext.jsx";
import "./styles.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AppProvider>
      <App />
    </AppProvider>
  </React.StrictMode>
);
